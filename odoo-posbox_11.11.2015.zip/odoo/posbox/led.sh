#/bin/bash-x
echo none > /sys/class/leds/led0/trigger
echo 255 > /sys/class/leds/led0/brightness
