#!/bin/bash -x
sudo systemctl start odoo.service;
sudo systemctl status odoo.service;
