#!/bin/bash -x
sudo systemctl status odoo.service;
