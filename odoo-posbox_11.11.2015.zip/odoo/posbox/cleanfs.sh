#!/bin/bash 
rm -rf /var/run/odoo/sessions/*


