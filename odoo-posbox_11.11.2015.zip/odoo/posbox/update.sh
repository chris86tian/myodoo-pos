#!/bin/bash -x
/home/pi/odoo/odoo.py -u all -d posbox --stop-after-init;
