# -*- coding: utf-8 -*-


from . import test_inheritance, test_extension, test_delegation
