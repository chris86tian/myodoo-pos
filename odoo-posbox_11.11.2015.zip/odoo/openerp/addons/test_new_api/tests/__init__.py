# -*- coding: utf-8 -*-

from . import test_related
from . import test_new_fields
from . import test_onchange
from . import test_field_conversions
from . import test_attributes
from . import test_no_infinite_recursion
