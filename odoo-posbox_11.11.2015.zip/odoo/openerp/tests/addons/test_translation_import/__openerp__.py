# -*- coding: utf-8 -*-
{
    'name': 'test-translation-import',
    'version': '0.1',
    'category': 'Tests',
    'description': """A module to test translation import.""",
    'author': 'OpenERP SA',
    'maintainer': 'OpenERP SA',
    'website': 'http://www.openerp.com',
    'depends': ['base'],
    'data': ['view.xml'],
    'test': ['tests.yml'],
    'installable': True,
    'auto_install': False,
}
